/* According to the assignment, the program should prompt the user to specify the desired type of translation,
 * input a string of Morse code characters or English characters, then display the translated results.
 * The Morse code pattern and English letter translations must be kept and processed using either two one-dimensional or one two-dimensional arrays.
 * The program only needs to handle a single sentence and can ignore punctuation symbols as well as digits, per Prof. Ferguson's email on June 25th, 2019.
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Module 5
 */

import java.util.Scanner;
public class MorseCodeTranslator {
   public static void main(String[] args) {
      //Two one-dimensional arrays are initialized below, with one being assigned the letters in English and the other array the equivalent characters in Morse code
      char[] Alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
      String[] MorseCode = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...",
         "-", "..-", "...-", ".--", "-..-", "-.--", "--..", "|"};
      Scanner input = new Scanner(System.in);
      System.out.println("Please enter \"morse\" to translate Morse Code into English or \"eng\" to translate English into Morse Code:");
      String translationChoice = input.nextLine();
      if (translationChoice.equalsIgnoreCase("morse")) {//Morse Code to English translator
         System.out.println("Please input a Morse code pattern by separating each letter with a single space and delimiting multiple words with a \"|\":");
         String textInMorseCode = input.nextLine();
         String[] userInputMorse = null; //Since null means that the String Object has not been instantiated, this allows the array to be 'filled' later
         if (textInMorseCode.contains("|")) {
            //In my research for this assignment, I came across a source code that helped me with the logic behind assigning multiple words in Morse to the same array
            //The source is as follows: https://stackoverflow.com/questions/32239768/
            
            userInputMorse = textInMorseCode.split("[|]"); //Splits Morse string on "|"
         } else {
            userInputMorse = new String[1];
            userInputMorse[0] = textInMorseCode;
         }
         for (String word : userInputMorse) {//The enhanced for loop is useful when iterating an array. Logic was based on research and the source previously cited
            String[] characters = word.split(" "); //Morse characters are kept in this array
            for (int initialLookup = 0; initialLookup < characters.length; initialLookup++) {//Initial Lookup is initialized, conditioned and incremented
               for (int morseMatch = 0; morseMatch < MorseCode.length; morseMatch++) {
                  if (characters[initialLookup].equals(MorseCode[morseMatch])) {
                     System.out.print(Alphabet[morseMatch]);
                  }
               }
            }
            System.out.print(" ");
         }
      }
      else if ( translationChoice.equalsIgnoreCase("eng")) {//English to Morse Code translator
         System.out.println("Please write a sentence in English, by separating each word with a blank space:");
         String textInEnglish = input.nextLine();
         textInEnglish = textInEnglish.toLowerCase(); //English words changed to lower case per the assignment instructions
         for (int secondLookup = 0; secondLookup < textInEnglish.length(); secondLookup++) {//Second Lookup is initialized, conditioned and incremented, 
            for (int englishMatch = 0; englishMatch < Alphabet.length; englishMatch++) {//Nested for loop logic based on previously cited source
               if (Alphabet[englishMatch] == textInEnglish.charAt(secondLookup))
                  System.out.print(MorseCode[englishMatch] + " ");
            }
         }
      }
      else {
         System.out.println ( "Invalid Input" );
      }
      input.close();
      System.out.println();
   }
}