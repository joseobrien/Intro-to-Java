package contactList;

/**
 * This Contact class sets the contact details (First and last name, a phone number and an email address) 
 * for any of the contacts that will be added to the Contact List.
 * 
 * The principal source used throughout the assignment can be found here: https://www.chegg.com/homework-help
 * 
 * @author Jose O'Brien
 * @version 1
 *
 */
public class Contact {

   /**
    * Defines method to set contact name
    * 
    * @param contactName full name of the contact as a String
    */
   public void setName(String contactName) {
      this.contactName = contactName; //Sets contactName
   }   

   /**
    * Defines method to set the phone number
    * 
    * @param contactPhoneNum contact phone number as a String
    */
   public void setPhoneNumber(String contactPhoneNum) {    
      this.contactPhoneNum = contactPhoneNum; //Set the contact phone number
   }

   /**
    * Defines method to set the contact email
    * 
    * @param contactEmail contact email as a String
    */
   public void setEmail(String contactEmail) {
      this.contactEmail = contactEmail; //Set the contact email
   }

   /**
    * Defines method to get the contact name
    * 
    * @return contact name in the contact list
    */

   public String getName() {  
      return contactName; 
   }

   /**
    * Defines method to get the contact phone number
    * 
    * @return contact phone number in the contact list
    */
   public String getMyContactPhoneNumber() {
      return contactPhoneNum; 
   }

   /**
    * Defines method to get the contact email
    * 
    * @return email of contact found in the contact list file
    */

   public String getMyContactEmail() {    
      return contactEmail; 
   }

   /**
    * Defines method to represent contact details as string
    * 
    * @return contact details of the registered contacts in the contacts file
    */
   public String toString() {
      return "\tName:"+contactName+"\n\tPhone Number:"+ contactPhoneNum + "\n\tEmail:"+contactEmail+"\n";
   }

   private String contactName; //Declares contactName
   private String contactPhoneNum; //Declares contactPhoneNum
   private String contactEmail; //Declares contactEmail
}