package contactList;

import java.util.*;
import java.util.HashMap;
import java.io.*;

/**
 * This ContactList class defines the list of contacts, how they are to be displayed and stored in a text file to be named by the user. 
 * 
 * The principal source used throughout the assignment can be found here: https://www.chegg.com/homework-help
 * 
 * @author Jose O'Brien
 * @version 1
 *
 */
public class ContactList {

   /**
    * Contains the main arguments (File to be saved, map declaration, gets user choice) to be executed and displayed in the program
    * 
    * @param args main arguments to be executed and displayed
    */
   public static void main(String[] args) throws Exception {
      String fileToSave = null; //Declares file to save
      Scanner inpScaner = new Scanner(System.in);
      int count=1; //Declares and initializes the count
      HashMap< Integer,Contact > myContactList = new HashMap< >(); //Declares map to create the contacts list
      displayProgramMenu();
      int myUserCh = inpScaner.nextInt(); //Gets user choice

      while(true) {

         switch(myUserCh) { //Switch statement to allow the different contact options available to the user

         case 1: //if user choice is 1, then displays all contact details
            String m=inpScaner.nextLine(); 
            for(int kk=0;kk<count-1;kk++) { //Loop to display all contact details
               System.out.println(myContactList.get(kk+1));
            }
            break;

         case 2: //If user choice is 2, adds new contact
            m=inpScaner.nextLine(); 
            Contact newContact = new Contact(); //Creates new contact
            System.out.print("Enter name: ");            
            newContact.setName(inpScaner.nextLine()); //Gets name
            System.out.print("Enter phone number(E.g., 201-555-5555): ");
            newContact.setPhoneNumber(inpScaner.nextLine()); //Gets phone number
            System.out.print("Enter email: ");
            newContact.setEmail(inpScaner.nextLine()); //Gets email address
            myContactList.put(count, newContact); //Adds new contact to the list
            count++;
            break;

         case 3: //If user choice 3, deletes contact detail
            m=inpScaner.nextLine();
            System.out.print("Enter name to delete from list: "); 
            String name=inpScaner.nextLine();

            for(int kk=0;kk<count-1;kk++) { //Loop to check the address book
               Contact tp =(Contact)myContactList.get(kk+1); //Gets current contact details

               if(tp.getName().equals(name)) { 

                  for(int aa=kk+1; aa<count-1;aa++) { //Removes current contact
                     System.out.println(aa);
                     Contact mp = (Contact)myContactList.get(aa+1);
                     myContactList.put(aa, mp);
                  }
                  count--; 
                  break;
               }
            }
            break;   

         case 4: //If choice is 4, saves the file
            System.out.print("Enter file name to save: "); 
            fileToSave = inpScaner.next(); //Gets file name
            BufferedWriter outContactFile = new BufferedWriter (new FileWriter(fileToSave)); //Creates print writer object

            for(int kk=0;kk<count-1;kk++) { //Loops to save data in the file indicated
               Contact tp =(Contact)myContactList.get(kk+1); //Gets current contact details
               outContactFile.write(tp.getName()); //Writes name in file
               outContactFile.newLine();           
               outContactFile.write( tp.getMyContactPhoneNumber()); //Writes phone number in file
               outContactFile.newLine();
               outContactFile.write(tp.getMyContactEmail()); //Writes email in file
               outContactFile.newLine();
            }

            outContactFile.flush(); //Flushes file
            outContactFile.close();
            System.out.println("Saved"); //Prints saved message
            System.exit(0);
            break;

         default:
            System.out.println("Invalid choice");
         }

         displayProgramMenu(); //Call Function
         myUserCh = inpScaner.nextInt(); //Gets user choice
      }
   }

   public static void displayProgramMenu() { //Defines method to display user menu
      System.out.println("(1) Display contact list");
      System.out.println("(2) Add Contact");
      System.out.println("(3) Delete contact");
      System.out.println("(4) Save contact list and Exit");
      System.out.print("Please enter a number from the menu to begin: ");
   }
}