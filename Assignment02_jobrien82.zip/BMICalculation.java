/*Calculation of Body Mass Index based on a person�s weight and height. 
 * 
 * It is calculated by dividing a person�s weight (in kilograms) by the square of a person�s height (in meters)
 * 
 * Also, the program will prompt the user to enter a weight (in pounds) and a height (in inches), 
 * which will then be converted to kilograms and meters, respectively, and then it will display their BMI, 
 * along with an evaluation of the user's BMI and official health information.
 * 
 */

import java.util.Scanner;

public class BMICalculation
{
   public static void main( String [] args )
   {
      //Define and initialize variables for values to be input
      double weight = 0;      // Weight value to be input in pounds
      double height = 0;      // Height value to be input in inches
      
      //Prompts user to input weight and height
      Scanner input = new Scanner( System.in );
      System.out.print("Enter weight in pounds: ");
      weight = input.nextFloat();
      
      System.out.print("Enter height in inches: ");
      height = input.nextFloat();
      
      //Conversions
      
      double weight2 = weight * 0.45359237;   // Conversion of weight value in kilograms
      double height2 = height * 0.0254;       // Conversion of height value in meters
      double bmi = weight2 / Math.pow(height2, 2);
      
      //Displays BMI
      System.out.println("\nYour BMI is: " + bmi);    
      
      //Evaluates the user's BMI
      if (bmi < 18.5 ) 
      {
         System.out.println("Underweight");
      }
      
      else if (bmi >= 18.5 && bmi < 25) 
      {
         System.out.println("Normal");
      }
      
      else if (bmi >= 25 && bmi < 30) 
      {
         System.out.println("Overweight");
      }
      
      else if (bmi >= 30) 
      {
         System.out.println("Obese");
         
         //Displays Department of Health & Human Services BMI ranges
      }
      
      System.out.println ("\nAccording to the Department of Health & Human Services/National Institutes of Health, a person is:" + "\n" + "1. Underweight if their BMI is less than 18.5" + "\n" + "2. Normal if their BMI is between 18.5 and 24.9" + "\n" + "3. Overweight if their BMI is between 25 and 29.9" + "\n" + "4. Obese if their BMI is 30 or greater");
      
   }
}