import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * This program allows the user to input two values, whole numbers or decimals, and then calculate their sum by clicking the Calculate button.
 * Additionally, the program includes a try and catch block to detect any exception to the values that are entered in the text fields.
 * 
 * @author Jose O'Brien
 * @version 1
 *
 */

public class SimpleCalculator {

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               SimpleCalculator window = new SimpleCalculator();
               window.frmSimpleCalculator.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the application.
    */
   public SimpleCalculator() {
      initialize();
   }

   private JFrame frmSimpleCalculator;
   private JTextField textFieldFirstValue;
   private JTextField textFieldSecondValue;
   private JTextField textFieldSum;
   
   /**
    * Initialize the contents of the frame.
    */
   private void initialize() {
      frmSimpleCalculator = new JFrame();
      frmSimpleCalculator.setTitle("Simple Calculator");
      frmSimpleCalculator.getContentPane().setEnabled(false);
      frmSimpleCalculator.getContentPane().setLayout(null);
      
      textFieldFirstValue = new JTextField();
      textFieldFirstValue.setBounds(119, 31, 151, 26);
      frmSimpleCalculator.getContentPane().add(textFieldFirstValue);
      textFieldFirstValue.setColumns(10);
      
      textFieldSecondValue = new JTextField();
      textFieldSecondValue.setBounds(119, 69, 151, 26);
      frmSimpleCalculator.getContentPane().add(textFieldSecondValue);
      textFieldSecondValue.setColumns(10);
      
      textFieldSum = new JTextField();
      textFieldSum.setBounds(119, 107, 151, 26);
      frmSimpleCalculator.getContentPane().add(textFieldSum);
      textFieldSum.setColumns(10);
      
      JButton btnNewButton = new JButton("Calculate");
      btnNewButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {
            float value1, value2, sum; //Used float in order to include decimal values to add            
            try {
               value1 = Float.parseFloat(textFieldFirstValue.getText()); //Assigns value entered in text field 1 to variable value1
               value2 = Float.parseFloat(textFieldSecondValue.getText()); //Assigns value entered in text field 2 to variable value2
               sum = value1 + value2; 
               textFieldSum.setText(Float.toString(sum)); //Assigns sum of value 1 and value 2 to textFieldSum             
            }
            catch(Exception e) {
               JOptionPane.showMessageDialog(null, "Please enter a valid number");
            }
            
         }
      });
      btnNewButton.setBounds(136, 147, 117, 29);
      frmSimpleCalculator.getContentPane().add(btnNewButton);
      
      JLabel lblFirstValue = new JLabel("First Value:");
      lblFirstValue.setBounds(19, 36, 75, 16);
      frmSimpleCalculator.getContentPane().add(lblFirstValue);
      
      JLabel lblSecondValue = new JLabel("Second Value:");
      lblSecondValue.setBounds(18, 74, 89, 16);
      frmSimpleCalculator.getContentPane().add(lblSecondValue);
      
      JLabel lblSumIs = new JLabel("Sum is:");
      lblSumIs.setBounds(19, 112, 61, 16);
      frmSimpleCalculator.getContentPane().add(lblSumIs);
      frmSimpleCalculator.setBounds(100, 100, 333, 231);
      frmSimpleCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}