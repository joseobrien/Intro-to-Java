/**
 * This class converts a non-generic Java class into a generic and instantiates with an Integer, Double and String type
 * 
 * @author Jose O'Brien
 * 
 * @param <T> generic type that is parameterized over types 
 * 
 */
class Node<T> { //Doubly Linked list node

   /**
    * Constructor to create a new node
    * 
    * next and prev is by default initialized as null
    * 
    * @param data data of any type, as detailed in the class description
    */
   Node(T data) { //Use T to declare an object of any type, as a placeholder
      this.data = data;
   }

   /**
    * Gets data to be displayed
    * 
    * @return data to be linked in the list
    */
   public T getData() {
      return this.data;
   }

   /**
    * Sets the data to be displayed 
    * 
    * @param data data of any type, as detailed above
    */
   public void setData(T data) {
      this.data = data;
   }

   /**
    * Gets the previous node on the list to be linked
    * 
    * @return previous node on the list
    */
   public Node getPrev() {
      return this.prev;
   }

   /**
    * Sets the previous node on the list
    * 
    * @param prev previous node to be linked
    */
   public void setPrev(Node prev) {
      this.prev = prev;
   }

   /**
    * Gets the next node in line
    * 
    * @return next node on the list
    */
   public Node getNext() {
      return this.next;
   }

   /**
    * Configures next node in the list
    * 
    * @param next next node to be linked 
    */
   public void setNext(Node next) {
      this.next = next;
   }

   private T data;
   private Node prev;
   private Node next;
}

/**
 * This class contains the Doubly Linked List with Generics type
 * 
 * @author Jose O'Brien
 *
 * @param <T> generic type that is parameterized over types
 */
public class DLL<T> {

   /**
    * Adds a node at the front of the list
    * 
    * @param new_data
    */ 
   public void push(T new_data) { 
      // 1. allocate node
      // 2. put in the data
      Node<T> new_Node = new Node<T>(new_data);

      // 3. Make next of new node as head and previous as NULL
      new_Node.setNext(head);
      new_Node.setPrev(null);

      // 4. change prev of head node to new node
      if (head != null) {
         head.setPrev(new_Node);
      }

      // 5. move the head to point to the new node
      head = new_Node;
   }

   /**
    * Given a node as prev_node, insert a new node after the given node
    * 
    * @param prev_Node previous node in the list
    * @param new_data new data to be displayed
    */
   public void InsertAfter(Node<T> prev_Node, T new_data) {

      // 1. check if the given prev_node is NULL
      if (prev_Node == null) {
         System.out.println("The given previous node cannot be NULL ");
         return;
      }

      // 2. allocate node
      // 3. put in the data
      Node<T> new_node = new Node<T>(new_data);

      // 4. Make next of new node as next of prev_node
      new_node.setNext(prev_Node.getNext());

      // 5. Make the next of prev_node as new_node
      prev_Node.setNext(new_node);

      // 6. Make prev_node as previous of new_node
      new_node.setPrev(prev_Node);

      // 7. Change previous of new_node's next node
      if (new_node.getNext() != null) {
         new_node.getNext().setPrev(new_node);
      }
   }

   /**
    * Adds a node at the end of the list
    * 
    * @param new_data new data to be displayed
    */
   void append(T new_data) {
      // 1. allocate node
      // 2. put in the data
      Node<T> new_node = new Node<T>(new_data);

      Node<T> last = head; // used in step 5

      // 3. This new node is going to be the last node, so make next of it as NULL
      new_node.setNext(null);

      // 4. If the Linked List is empty, then make the new node as head
      if (head == null) {
         new_node.setPrev(null);
         head = new_node;
         return;
      }

      // 5. Else traverse till the last node
      while (last.getNext() != null) {
         last = last.getNext();
      }

      // 6. Change the next of last node
      last.setNext(new_node);

      // 7. Make last node as previous of new node
      new_node.setPrev(last);
   }

   /**
    * This function prints contents of linked list starting from the given node
    * 
    * @param node given node to be displayed in the list
    */
   public void printlist(Node<T> node) {
      Node<T> last = null;
      System.out.println("Traversal in forward Direction");
      while (node != null) {
         System.out.print(node.getData() + " ");
         last = node;
         node = node.getNext();
      }
      System.out.println();
      System.out.println("Traversal in reverse direction");
      while (last != null) {
         System.out.print(last.getData() + " ");
         last = last.getPrev();
      }
   }

   /**
    * Drier program to test above functions
    * 
    * @param args arguments of the main method, testing above functions
    */
   public static void main(String[] args) {
      //Start with the empty list
      DLL<Integer> dll = new DLL<Integer>(); //Add the specific type to be input here, Generics allows changes to this and future types 

      // Insert 1, in this case so linked list becomes 1->NULL
      dll.append(1);

      // Insert 5 at the beginning. So linked list becomes 1->5->NULL
      dll.append(5);

      // Insert 10 at the beginning. So linked list becomes 1->5->10->NULL
      dll.append(10);

      System.out.println("Created DLL is: ");
      dll.printlist(dll.head);

      System.out.println("\n--------------------------------");

      //Start with the empty list
      DLL<Double> dll2 = new DLL<Double>(); //Add the specific type to be input here, in this case, Double

      // Insert 2.0. So linked list becomes 2.0->NULL
      dll2.append(2.0);

      // Insert 6.0 at the beginning. So linked list becomes 2.0->6.0->NULL
      dll2.append(6.0);

      // Insert 12.0 at the beginning. So linked list becomes 2.0->6.0->12.0->NULL
      dll2.append(12.0);

      System.out.println("Created DLL2 is: ");
      dll2.printlist(dll2.head);

      System.out.println("\n--------------------------------");

      //Start with the empty list
      DLL<String> dll3 = new DLL<String>(); //Add the specific type to be input here, in this case, String

      // Insert "Dog". So linked list becomes Dog->NULL
      dll3.append("Dog");

      // Insert "Cat" at the beginning. So linked list becomes Dog->Cat->NULL
      dll3.append("Cat");

      // Insert "Horse" at the beginning. So linked list becomes Dog->Cat->Horse->NULL
      dll3.append("Horse");

      System.out.println("Created DLL3 is: ");
      dll3.printlist(dll3.head);

      System.out.println("\n--------------------------------");

   }

   private Node head; // head of list
}