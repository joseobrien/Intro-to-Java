import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * This program allows users to perform a loan payment calculation. 
 * The user is prompted to enter the annual interest rate, the term of the loan and the loan amount.
 * The program then returns the monthly loan payment and the total loan payment (including interests).
 * Additionally, the program includes a try and catch block to detect any exception to the values that are entered in the text fields.
 * 
 * @author Jose O'Brien
 * @version 1
 *
 */

public class LoanCalculator {

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               LoanCalculator window = new LoanCalculator();
               window.frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the application.
    */
   public LoanCalculator() {
      initialize();
   }

   private JFrame frame;
   private JTextField textFieldIntRate;
   private JTextField textFieldNumYears;
   private JTextField textFieldLoanAmt;
   private JTextField textFieldMonthlyPymt;
   private JTextField textFieldTotalPymt;

   /**
    * Initialize the contents of the frame.
    */
   private void initialize() {
      frame = new JFrame();
      frame.setBounds(100, 100, 363, 300);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().setLayout(null);

      textFieldIntRate = new JTextField();
      textFieldIntRate.setBounds(151, 26, 153, 26);
      frame.getContentPane().add(textFieldIntRate);
      textFieldIntRate.setColumns(10);

      textFieldNumYears = new JTextField();
      textFieldNumYears.setBounds(151, 70, 153, 26);
      frame.getContentPane().add(textFieldNumYears);
      textFieldNumYears.setColumns(10);

      textFieldLoanAmt = new JTextField();
      textFieldLoanAmt.setBounds(151, 114, 153, 26);
      frame.getContentPane().add(textFieldLoanAmt);
      textFieldLoanAmt.setColumns(10);

      textFieldMonthlyPymt = new JTextField();
      textFieldMonthlyPymt.setBounds(151, 158, 153, 26);
      frame.getContentPane().add(textFieldMonthlyPymt);
      textFieldMonthlyPymt.setColumns(10);

      textFieldTotalPymt = new JTextField();
      textFieldTotalPymt.setBounds(151, 202, 153, 26);
      frame.getContentPane().add(textFieldTotalPymt);
      textFieldTotalPymt.setColumns(10);

      JLabel lblIntRate = new JLabel("Annual Interest Rate:");
      lblIntRate.setBounds(17, 31, 140, 16);
      frame.getContentPane().add(lblIntRate);

      JLabel lblNumYears = new JLabel("Number of Years:");
      lblNumYears.setBounds(17, 75, 109, 16);
      frame.getContentPane().add(lblNumYears);

      JLabel lblLoanAmt = new JLabel("Loan Amount:");
      lblLoanAmt.setBounds(17, 119, 109, 16);
      frame.getContentPane().add(lblLoanAmt);

      JLabel lblMonthlyPymt = new JLabel("Monthly Payment:");
      lblMonthlyPymt.setBounds(17, 163, 124, 16);
      frame.getContentPane().add(lblMonthlyPymt);

      JLabel lblTotalPymt = new JLabel("Total Payment:");
      lblTotalPymt.setBounds(17, 207, 109, 16);
      frame.getContentPane().add(lblTotalPymt);

      JButton btnCalculate = new JButton("Calculate");
      btnCalculate.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent arg0) {

            double intRate, perIntRate, loanAmt, monthlyPymt, totalPymt; //Used double in order to include precise decimal values to calculate payments
            int numYears, numPeriods; //Used integers given that years and periods (months) are whole numbers

            try {
               intRate = Double.parseDouble(textFieldIntRate.getText()); //Assigns value entered in the first text field to variable intRate
               loanAmt = Double.parseDouble(textFieldLoanAmt.getText()); //Assigns value entered in the second text field to variable loanAmt
               numYears = Integer.parseInt(textFieldNumYears.getText()); //Assigns value entered in the third text field to variable numYears

               perIntRate = (intRate / 100) / 12; //New variable for periodic interest rate, used to simplify calculation
               numPeriods = numYears * 12; //New variable for number of periods (months), used to simplify calculation

               monthlyPymt = (double) ((perIntRate * loanAmt) / (1 - Math.pow((1 + perIntRate), -numPeriods))); //Formula given in assignment
               totalPymt = numPeriods * monthlyPymt; 

               BigDecimal bigDec1 = new BigDecimal(monthlyPymt).setScale(2, RoundingMode.HALF_EVEN); //Monthly payment rounded to 2 decimal places
               double newMonthlyPymt = bigDec1.doubleValue();

               BigDecimal bigDec2 = new BigDecimal(totalPymt).setScale(2, RoundingMode.HALF_EVEN); //Total payment rounded to 2 decimal places
               double newTotalPymt = bigDec2.doubleValue();               

               textFieldMonthlyPymt.setText(Double.toString(newMonthlyPymt)); //Assigns monthly payment value to textFieldMonthlyPymt   
               textFieldTotalPymt.setText(Double.toString(newTotalPymt)); //Assigns total payment value to textFieldTotalPymt 
            }
            catch(Exception e) {
               JOptionPane.showMessageDialog(null, "Please enter a valid number");
            }            
         }
      });
      btnCalculate.setBounds(187, 243, 117, 29);
      frame.getContentPane().add(btnCalculate);
   }
}