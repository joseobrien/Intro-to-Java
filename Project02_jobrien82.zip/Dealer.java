package blackjack;
import java.util.ArrayList;

/**This class creates the the dealer that will hand out the cards and will play blackjack against the player.
 * 
 * @author  Jose O'Brien
 * @version 1
 */

class Dealer {
   ArrayList<Card> hand;//represents the dealer's hand
   Dealer(Deck deck) {
      hand = new ArrayList<>();
      aHand = new Card[]{};
      int AceCounter=0;
      for(int i=0; i<2; i++) {
         hand.add(deck.drawCard());
      }
      aHand = hand.toArray(aHand);
      for(int i=0; i<aHand.length; i++) {
         handvalue += aHand[i].getValue();
         if(aHand[i].getValue()==11) {
            AceCounter++;
         }
         while(AceCounter>0 && handvalue>21) {
            handvalue-=10;
            AceCounter--;
         }
      }
   }

   /**
    * Prints the dealer's first card, the card that is face up at the beginning of a game.
    */
   public void showFirstCard() {
      Card[] firstCard = new Card[]{};
      firstCard = hand.toArray(firstCard);
      System.out.println("["+firstCard[0]+"]");
   }

   /**
    * Hands another card to the dealer and updates the total value of their hand.
    * @param deck the cards available in the deck after the cards that have been handed out
    */
   public void Hit(Deck deck) {
      hand.add(deck.drawCard());
      aHand = hand.toArray(aHand);
      handvalue = 0;
      for(int i=0; i<aHand.length; i++) {
         handvalue += aHand[i].getValue();
         if(aHand[i].getValue()==11) {
            AceCounter++;
         }
         while(AceCounter>0 && handvalue>21) {
            handvalue-=10;
            AceCounter--;
         }
      }
   }

   /**
    * Determines if the dealer wants to hit according to blackjack game rules.
    * @return the confirmation of whether the value of the dealer's hand is below 17
    */
   public boolean wantsToHit() {
      if(handvalue<17) {
         return true;
      }
      return false;
   }

   /**
    * Returns true if the dealer has blackjack.
    * @return the confirmation of whether a dealer has reached blackjack
    */
   public boolean hasBlackJack() {
      if(hand.size()==2 && handvalue==21) {
         System.out.println("The dealer has blackjack!");
         return true;
      }
      return false;
   }

   /**
    * Prints the dealer's hand.
    */
   public void showHand() {
      System.out.println(hand);
   }

   /**
    * Returns the value of the dealer's hand.
    * @return the current accumulated value that the dealer has in their hand
    */
   public int getHandValue() {
      return handvalue;
   }

   /**
    * Determines if a dealer has busted.
    * @param handvalue the value of the dealer's hand during a game of blackjack
    * @return          the confirmation of whether the dealer's hand value is over 21
    */
   public boolean busted(int handvalue) {
      if(handvalue>21) {
         System.out.println("The dealer busted!");
         return true;
      }
      return false;
   }

   /**
    * Takes the turn for the dealer and returns the value of his hand.
    * @param deck the cards available in the deck after the cards that have been handed out
    * @return     the value of the dealer's hand during a game of blackjack

    */
   public int takeTurn(Deck deck) {
      while(wantsToHit()) {
         System.out.println("The dealer hits");
         Hit(deck);
         if(busted(handvalue)) {
            break;
         }
      }
      if(handvalue<=21) {
         System.out.print("The dealer stands.");
      }
      return handvalue;
   }
   private int handvalue=0;//value of the dealer's hand (starts at 0)
   private Card[] aHand;//used to convert the dealer's hand to an array
   private int AceCounter;//counts the aces in the dealer's hand
}