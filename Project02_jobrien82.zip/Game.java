package blackjack;
import java.util.*;

/**This class simulates multiple games of Blackjack, if the player so chooses, by performing the following on a loop:
 * <p>
 * Asks the player for amount of money to start with. 
 * The player then places a bet for an amount lower than the initial amount.
 * Game and dealer are dealt their two corresponding cards (both face up for the player and only one face up for the dealer). 
 * After these cards are dealt, the program checks if either the player or dealer has Blackjack.
 * In case the player has bet less than half of the initial cash amount, the player is asked if they'd like to double down on their bet. 
 * The game then proceeds by asking if the player will hit or stay.
 * Then, the program checks if the player has won, busted and if they'd like to continue playing, in case there is money still available from the initial amount.
 * 
 * @author  Jose O'Brien
 * @version 1
 */

public class Game {

   public void run() {
      System.out.println("Welcome, let's play a game of BlackJack!");
      System.out.println("But first, please enter the amount you want to start with?");
      Scanner money = new Scanner(System.in);
      cash = money.nextInt();
      System.out.println("Great, you'll start with: " + cash);

      while(cash>0) {
         Deck deck = new Deck(); //Initializes the deck, dealer, hands and configures the bet.
         deck.shuffle();
         AceCounter=0;
         Dealer dealer = new Dealer(deck);
         List<Card> hand = new ArrayList<>();
         hand.add(deck.drawCard());
         hand.add(deck.drawCard());
         System.out.println("How much would you like to bet?");
         bet=Bet(cash);
         System.out.println("Cash:"+(cash-bet));
         System.out.println("Money on the table:"+bet);
         System.out.println("Here is your hand: ");
         System.out.println(hand);
         int handvalue = calcHandValue(hand);
         System.out.println("The dealer is showing: ");
         dealer.showFirstCard();

         if(hasBlackJack(handvalue) && dealer.hasBlackJack()) { //Checks if BOTH the user and dealer have blackjack.
            Push();
         }

         else if(hasBlackJack(handvalue)) { //Checks if only the player has blackjack from the first two cards handed out.
            System.out.println("You have BlackJack!");
            System.out.println("You get back twice your money!");
            cash=cash+bet;
            Win();
         }

         else if(dealer.hasBlackJack()){ //Checks if only the dealer has blackjack from their first two cards handed out.
            System.out.println("Here is the dealer's hand:");
            dealer.showHand();
            Lose();
         }

         else {

            if(2*bet<cash) { //Checks if the user can double down in case of a bet less than half their money available.
               System.out.println("Would you like to double down?");
               Scanner doubledown = new Scanner(System.in);
               String doubled = doubledown.nextLine();
               while(!isyesorno(doubled)) {
                  System.out.println("Please enter yes or no.");
                  doubled = doubledown.nextLine();
               }
               if(doubled.equals("yes")) {
                  System.out.println("You have opted to double down!");
                  bet=2*bet;
                  System.out.println("Cash:"+(cash-bet));
                  System.out.println("Money on the table:"+bet);
               }
            }

            System.out.println("Would you like another hit or do you stay?"); //Asks if the player wants another hit or stays.
            Scanner hitorstay = new Scanner(System.in);
            String hitter = hitorstay.nextLine();
            while(!isHitorStay(hitter)){
               System.out.println("Please enter 'hit' or 'stay'.");
               hitter = hitorstay.nextLine();
            }

            while(hitter.equals("hit")){ //Player can ask for as many hits as they'd like until they bust.
               Hit(deck, hand);
               System.out.println("Your hand is now:");
               System.out.println(hand);
               handvalue = calcHandValue(hand);

               if(checkBust(handvalue)) { //Checks if the player busted
                  Lose();
                  break;
               }

               if(handvalue<=21 && hand.size()==5) { //Checks if the player holds five cards in their hand, which is known as a five card trick.
                  fivecardtrick();
                  break;
               }
               System.out.println("Would you like another hit or do you stay?");
               hitter = hitorstay.nextLine();
            }

            if(hitter.equals("stay")) { //Allows the player to stay.
               int dealerhand = dealer.takeTurn(deck); //Considers the dealer's turn.
               System.out.println("");
               System.out.println("Here is the dealer's hand:");
               dealer.showHand();

               if(dealerhand>21) { //Player wins if the dealer goes bust.
                  Win();
               }

               else {
                  int you = 21-handvalue; //Checks whether the player of dealer are closer to blackjack, thus determining the winner.
                  int deal = 21-dealerhand;
                  if(you==deal) {
                     Push();
                  }
                  if(you<deal) {
                     Win();
                  }
                  if(deal<you) {
                     Lose();
                  }
               }
            }
         }

         System.out.println("Would you like to play again?"); //Loops as many games as the player would like to play as long as they have money available.
         Scanner yesorno = new Scanner(System.in);
         String answer = yesorno.nextLine();
         while(!isyesorno(answer)) {
            System.out.println("Please answer yes or no.");
            answer = yesorno.nextLine();
         }
         if(answer.equals("no")) {
            break;
         }
      }

      System.out.println("Your cash is: "+cash); //Game ends either if the player no longer wants to play or if they run out of cash.
      if(cash==0) {
         System.out.println("You ran out of cash!");
      }
      else {
         System.out.println("Thanks for playing!");
      }


   }
   /**
    * Checks if the player has blackjack.
    * @param handvalue the value of the player's hand during a game of blackjack
    * @return          the confirmation of whether a player's hand has a blackjack or not
    */
   public static boolean hasBlackJack(int handvalue) {
      if(handvalue==21) {
         return true;
      }
      return false;
   }

   /**
    * Calculates the value of a player's hand.
    * @param hand the array containing accumulated values of the player's hand
    * @return     the aggregate value of the player's hand
    */
   public static int calcHandValue(List<Card> hand) {
      Card[] aHand = new Card[]{};
      aHand = hand.toArray(aHand);
      int handvalue=0;
      for(int i=0; i<aHand.length; i++) {
         handvalue += aHand[i].getValue();

         if(aHand[i].getValue()==11) {
            AceCounter++;
         }
         while(AceCounter>0 && handvalue>21) {
            handvalue-=10;
            AceCounter--;
         }
      }
      return handvalue;
   }

   /**
    * Asks the user how much they'd like to bet.
    * @param cash the amount of money available to the player at any given moment
    * @return     the amount of money placed on a bet for an individual game 
    */
   public static int Bet(int cash) {
      Scanner sc=new Scanner(System.in);
      int bet=sc.nextInt();
      while(bet>cash) {
         System.out.println("You cannot bet more cash than you have!");
         System.out.println("How much would you like to bet?");
         bet=sc.nextInt();
      }
      return bet;
   }

   /**
    * Called when the player wins a game.
    */
   public static void Win() {
      System.out.println("Congratulations, you win!");
      cash=cash+bet;
      System.out.println("Cash: "+cash);
   }

   /**
    * Called when the player loses a game.
    */
   public static void Lose() {
      System.out.println("Sorry, you lose!");
      cash=cash-bet;
      System.out.println("Cash: "+cash);
   }

   /**
    * Called when player pushes the dealer, that is, when they both have the same hand value.
    */
   public static void Push() {
      System.out.println("It's a push!");
      System.out.println("You get your money back.");
      System.out.println("Cash: "+cash);
   }

   /**
    * Adds a card to player's hand and recalculates the aggregate value of their hand.
    * @param deck the cards available in the deck after the cards that have been handed out
    * @param hand the array containing accumulated values of the player's hand
    */
   public static void Hit(Deck deck, List<Card> hand) {
      hand.add(deck.drawCard());
      Card[] aHand = new Card[]{};
      aHand = hand.toArray(aHand);
      handvalue = 0;

      for(int i=0; i<aHand.length; i++) {
         handvalue += aHand[i].getValue();
         if(aHand[i].getValue()==11) {
            AceCounter++;
         }
         while(AceCounter>0 && handvalue>21) {
            handvalue-=10;
            AceCounter--;
         }
      }
   }

   /**
    * Checks whether a player wants another hit or has chosen to stay.
    * @param hitter  the player's choice to have another hit or to stay
    * @return        the player's input, either another hit or stay
    */
   public static boolean isHitorStay(String hitter) {
      if(hitter.equals("hit") || hitter.equals("stay")) {
         return true;
      }
      return false;
   }

   /**
    * Determines if the player has busted.
    * @param handvalue the value of the player's hand during a game of blackjack
    * @return          whether the total value of the player's hand is higher than 21
    */
   public static boolean checkBust(int handvalue) {
      if(handvalue>21) {
         System.out.println("You have busted!");
         return true;
      }
      return false;
   }

   /**
    * Determines the answer of the player to any of the Yes/No questions during the game. 
    * @param answer the player's choice between yes or no
    * @return       whether the player's input is either yes or no 
    */
   public static boolean isyesorno(String answer) {
      if(answer.equals("yes") || answer.equals("no")) {
         return true;
      }
      return false;
   }

   /*
    * Called if the player has a five card trick.
    */
   public static void fivecardtrick() {
      System.out.println("You have achieved a five card trick!");
      Win();
   }

   private static int cash; //This is the initial amount of money the player starts with the first game 
   private static int bet; //Money the player has decided to bet with during each of the games 
   private static int AceCounter; //Counts how many aces are in the user's hand
   private static int handvalue; //Represents the value of the user's hand
}