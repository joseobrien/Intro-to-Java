package blackjack;

/**This class contains the main method which runs the blackjack game declared in the Game class. 
 * <p>
 * The principal source used throughout the assignment can be found here: 
 * https://www.chegg.com/homeworkhelp
 * 
 * @author  Jose O'Brien
 * @version 1
 */

public class BlackjackGameSimulator {

   public static void main(String[] args) {
      Game b = new Game();
      b.run();
   }
}
