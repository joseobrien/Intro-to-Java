package blackjack;

/**This class creates the cards that will be used during the games of blackjack between the player and the dealer.
 * 
 * @author  Jose O'Brien
 * @version 1
 */

class Card {
   /**
    * Composed of a spot in the String array ranks and the String array suits, which represents the rank and suit of an individual card.
    * @param suit  the suit of the card drawn
    * @param values the number value of the card drawn
    */
   Card(int suit, int values) {
      this.rank=values;
      this.suit=suit;
   }

   /**
    * Returns the string name of a card.
    * @return the value and suit of a card drawn
    */
   public String toString() {
      return ranks[rank]+" of "+suits[suit];
   }

   /**
    * Returns the rank of a card.
    * @return the rank of the card drawn, for values 10 an above
    */
   public int getRank() {
      return rank;
   }

   /**
    * Returns the suit of a card.
    * @return the suit of the card drawn
    */
   public int getSuit() {
      return suit;
   }

   /**
    * Returns the value of a card and if the card is a jack, queen, or king then the value is ten, while aces are 11.
    * @return the value of the rank card, for values 10 or above
    */
   public int getValue() {
      if(rank>10)
      {
         value=10;
      }
      else if(rank==1)
      {
         value=11;
      }
      else
      {
         value=rank;
      }
      return value;
   }

   /**
    * Sets the value of a card.
    * @param set the given value of a card after evaluating its rank, suit and value
    */
   public void setValue(int set) {
      value = set;
   }
   private int rank; //Equals the rank of a card
   private int suit; //Equals the suit of a card
   private int value; //Equals the value of a card
   private static String[] ranks = {"Joker","Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
   private static String[] suits = {"Clubs","Diamonds","Hearts","Spades"};
}