package blackjack;
import java.util.ArrayList;
import java.util.Random;

/**This class creates the deck of cards from which the Game class will draw to shuffle them and then hand them out to the player and the dealer.
 * 
 * @author  Jose O'Brien
 * @version 1
 */

class Deck {
   Deck() { //Represents a deck of cards
      deck = new ArrayList<Card>();
      for(int i=0; i<4; i++) {
         for(int j=1; j<=13; j++) {
            deck.add(new Card(i,j));
         }
      }
   }

   /**
    * Shuffles the deck by changing the indexes of 100 random pairs of cards in the deck.
    */
   public void shuffle() {
      Random random = new Random();
      Card temp;
      for(int i=0; i<100; i++) {
         int index1 = random.nextInt(deck.size()-1);
         int index2 = random.nextInt(deck.size()-1);
         temp = deck.get(index2);
         deck.set(index2, deck.get(index1));
         deck.set(index1, temp);
      }
   }

   /**
    * Draws a card from the deck.
    * @return the latest card to be drawn from the deck
    */
   public Card drawCard() {
      return deck.remove(0);
   }
   private ArrayList<Card> deck; 
}