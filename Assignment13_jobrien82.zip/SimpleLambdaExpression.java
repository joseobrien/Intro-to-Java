import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * This program uses Lambda expressions to determine then return the minimum, maximum, and average of a series of numbers 
 * It also sorts the numbers using Collections.sort(), calls a Lambda Block to calculate and return the median then prints the median
 * 
 * The principal source used throughout the assignment can be found here: https://www.chegg.com/homework-help
 * 
 * @author Jose O'Brien
 * @version 1
 *
 */

public class SimpleLambdaExpression {

   /**
    * The method lambdaBlock will take a List of numbers as parameter and will return the median.
    * 
    * @param List<Double> listOfNumbers
    * @return median value calculated in this method
    */

   public static double lambdaBlock(List<Double> listOfNumbers){
      double maximum, minimum, average, median;

      maximum = listOfNumbers.stream().max(Comparator.comparing(number -> number)).get(); //Gets the max number in the array
      System.out.println("Maximum: " + maximum);

      minimum = listOfNumbers.stream().min(Comparator.comparing(number -> number)).get(); //Gets the min number in the array
      System.out.println("Minimum: " + minimum);

      average = listOfNumbers.stream().mapToDouble(number -> number).average().getAsDouble(); //Gets the average value in the array
      System.out.println("Average: " + String.format("%.02f", average));

      Collections.sort(listOfNumbers); //Sorts array prior to finding the median value 
      median = listOfNumbers.size() / 2;
      if (listOfNumbers.size()%2 == 0) {
         median = (listOfNumbers.get(listOfNumbers.size()/2) + listOfNumbers.get(listOfNumbers.size()/2 - 1))/2;
      } 
      else {
         median = (listOfNumbers.get(listOfNumbers.size()/2));
      }

      return median;
   }

   /**
    * Demonstrates the lambda expressions in the lambdaBlock() are working
    * @param args main arguments that contain the array and the median print
    */
   public static void main(String[] args) {

      List<Double> listOfNumbers = Arrays.asList(17.64, 55.56, 36.93, 55.96, 20.23, 41.74, 1.8, 95.97, 81.89, 36.16, 34.41, 87.9, 13.74, 11.15);

      double median = lambdaBlock(listOfNumbers);
      System.out.println("Median: " + String.format("%.02f", median));
   }
}