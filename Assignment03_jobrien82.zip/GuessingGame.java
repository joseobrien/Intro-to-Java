/* According to the assignment, the program should prompt the user to guess a secret number between 1 and N, where N is a positive number that is asked of the user. 
 * In addition, the user should also be prompted for the maximum number of guesses they would like to make. 
 * Each time the player makes a guess, the program will respond with �correct�, �too low�, or �too high�. 
 * The program should continue execution until the user has discovered the random number OR has exceeded the maximum number of guesses. 
 * Once the Guessing Game ends, the user is prompted if they'd like to play again or not.
 * 
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Module 3 Part 2
 */

import java.util.Scanner;

public class GuessingGame
{
   public static void main(String args[]) 
   {       
      String userAnswer;
      do
      { //Do while construct was chosen in order to execute the program until the user declines to continue playing the game
         
         int tries = 1;
         //This integer is introduced in order to keep track of guesses which should not exceed the # entered by the user 
         
         boolean win = false;
         
         Scanner input = new Scanner(System.in);
         //Scanner prompts the user to input the number of asterisks they want displayed 
         
         System.out.println("Welcome to my Guessing Game! Please follow the user prompts as they appear.");
         
         System.out.print("First, let's define the maximum value for this game. You will be guess a number from 1 to: ");
         int n = input.nextInt();
         //Integer "n" is stored here so it can be used as the maximum value in the random number range
         
         System.out.print("Then, let's define how many guesses you'd like to have for this game: ");
         int userTries = input.nextInt();
         
         int randomNumber = (int) (n * Math.random() ) + 1;
         //Random formula was given in the assignment Word document
         
         while ((win == false) && (tries <= userTries))
         { //A while loop with multiple conditions is used here to allow multiple attempts to guess the random number 
            
            System.out.print("Please enter your guess here: ");
            int guess = input.nextInt(); 
            
            tries++;
            //Keeps track of the number of tries and adds 1 after every attempt
            if (guess == randomNumber)
               
            { //If the user's guess matches the random number the program jumps to the end so the user can choose to play again or not
               
               System.out.println ("Your guess is correct, congratulations.");
               win = true;
            }
            else if (guess < randomNumber)
            {
               System.out.println ("Your guess is too low.");
            }
            else if (guess > randomNumber)
            {   
               System.out.println ("Your guess is too high.");
            }
         }   
         
         System.out.println ("Game over, do you want to play again? Yes or No");
         userAnswer = input.next(); 
         System.out.println();
      }
      while (userAnswer.equals("Yes")); 
      //Here, the user is prompted to play again or not, I tried using equalsIgnoreCase but I seem to have problems in compilation
      //Also, I tried closing the resource leak (input.close) but I also get compilations problems so I left it out of the source code
   }  
}