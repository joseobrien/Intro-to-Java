/* According to the assignment, the program should prompt the user to enter the maximum number of asterisks (*) to display on a line of output.
 * Also, the user should be able to choose from one of two output patterns. 
 * 
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Module 3 Part 1
 */

import java.util.Scanner;

public class AsteriskPyramid
{
   public static void main(String args[]) 
   {        
      Scanner input = new Scanner(System.in); 
      //Scanner prompts the user to input the number of asterisks they want displayed 
      
      System.out.print("Please input the maximum number of asterisks you would like to use for the Asterisk Pyramid: ");
      int asterisks = input.nextInt();
      
      System.out.print("Please choose an output pattern, input either '1' for lowest to highest OR '2' for highest to lowest: ");
      int int1 = input.nextInt();
      
      input.close();  
      
      switch (int1) 
      { //Given that there are 2 output patterns to choose from, I decided to treat each of them as a case within a switch statement
         
         case 1: 
         { //Case 1 is the first output pattern, from lowest to highest number of asterisks  
            
            for (int a = 1; a <= asterisks; a++)  
            { //The for loop has a condition less than or equal to the # of asterisks entered by the user
               
               for (int b = 0; b < a; b++)        
               { //This for loop allows the program to print as many asterisks as the row number we're currently on      
                  
                  System.out.print("*");
               }
               System.out.println();
            }
            break;
         }
         
         case 2: 
         { //Case 2 is the second output pattern, from highest to lowest number of asterisks   
            
            for (int a = asterisks; a >= 0; a--)
            {
               for (int b = 0; b < a; b++)
               {      
                  System.out.print("*");
               }
               System.out.println();
            }
            break;
         }    
         
         default: 
         { //This default case is written out to close out the switch statement
            
            System.out.println("No asterisks to display");
            break;
         }
      }
      System.out.println();
      System.out.println("Thank you for playing this game!");
   }
}