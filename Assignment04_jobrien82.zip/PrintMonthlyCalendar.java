/* According to the assignment, the program should prompt the user to enter a month (1-12) and a year (e.g., 2012),
 * and then display the calendar for that month and year.
 * There were a series of methods that had to be used; all have been included in the source code below.
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Module 4 Part 1
 */

import java.util.Scanner;

public class PrintMonthlyCalendar {
   
   /* The Main method is static while the other methods are non-static.
    * According to the Java Coding and Design Guidelines, static variables make the design more complex
    * as you need to make sure that the access to static variables in a multi-threaded environment is synchronized.
    */
   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      
      System.out.print("Please enter a year (e.g., 2019): ");
      int year = input.nextInt();
      
      System.out.print("Please enter a month in number (e.g., 6 for June): ");
      int month = input.nextInt();
      System.out.println();
      
      /* One of the ways for Java to access non-static variables and methods is by creating a new object, as seen below.
       * This is particularly important since the scope of the global variables and methods are available across all the functions.
       */
      PrintMonthlyCalendar obj = new PrintMonthlyCalendar();
      obj.printMonth(year, month); // The method "printMonth" is accessed by using an object
      input.close (); // Closes the resource leak, Scanner input
   }
   public void printMonth(int year, int month) { // The printMonth method is composed of two additional methods, printMonthTitle and printMonthBody
      printMonthTitle(year, month);
      printMonthBody(year, month);
   }
   public void printMonthTitle(int year, int month) { // The printMonthTitle method is itself made up of a method, getMonthName
      System.out.println("\t" + getMonthName(month) + " " + year);
      System.out.println("-----------------------------");
      System.out.println(" Sun Mon Tue Wed Thu Fri Sat");
   }
   public  String getMonthName(int month) {
      String[] monthName = { // The first month is left blank so that January can be number 1
         "", "January", "February", "March",
         "April", "May", "June",
         "July", "August", "September",
         "October", "November", "December"
      };
      return monthName[month];
   }
   public void printMonthBody(int year, int month) { // This method gets the day of the week in which a particular month starts
      int startDay = getStartDay(year, month);
      int numberOfDaysInMonth = getNumberOfDaysInMonth(year, month); // Gets the number of days in a particular month
      int dayMovement; // The 1st of a particular month needs to be moved to its corresponding day of the week
      for (dayMovement = 0; dayMovement < startDay; dayMovement++)
         System.out.print("    ");
      for (dayMovement = 1; dayMovement <= numberOfDaysInMonth; dayMovement++) {
         System.out.printf("%4d", dayMovement);
         if ((dayMovement + startDay) % 7 == 0) // Positions the 1st day of the month in the corresponding day of the week
            System.out.println();
      }
      System.out.println();
   }
   
   /* Although Zeller's numbering system was given, this method could not display the 1st day of months with other than 30 days
    * In my research and additional reading for this assignment, I came across the following source code that helped me with the getStartDay method
    * The source is as follows: https://liveexample.pearsoncmg.com/html/PrintCalendarWithLineNumber.html?
    */
   
   public int getStartDay(int year, int month) { // Gets total number of days from 1/1/1800 to 1st day of any given month
      final int START_DAY_FOR_JAN_1_1800 = 3;
      int totalNumberOfDays = getTotalNumberOfDays(year, month);
      return (totalNumberOfDays + START_DAY_FOR_JAN_1_1800) % 7; // Returns the start day for any given month
   }
   
   public int getTotalNumberOfDays(int year, int month) { // This method gets the total number of days since January 1, 1800, as outlined in the above source link
      int total = 0;
      for (int i = 1800; i < year; i++) // Gets the total days from 1800 to January 1st of any given year
         if (isLeapYear(i))
         total = total + 366;
      else
         total = total + 365;
      for (int i = 1; i < month; i++) // Adds the days from January to the month prior to the calendar month
         total = total + getNumberOfDaysInMonth(year, i);
      return total;
   }
   public int getNumberOfDaysInMonth(int year, int month) { // This method gets the number of days in any given month
      if (month == 2) return isLeapYear(year) ? 29 : 28; //Use of ternary operator simplifies the true/ false statement
      else if (month == 4 || month == 6 || month == 9 || month == 11) return 30;
      else return 31;
   }
   public boolean isLeapYear(int year) { // This last method determines whether a year is a leap year or not, as outlined in the source link previously cited
      return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
   }
}