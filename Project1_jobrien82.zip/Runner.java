package tortoiseHareRace;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public abstract class Runner {//Abstract class is used only because the runner class should not be instantiated into an object
   private static Random random = new Random(); //This is private because random numbers will only be generated in this class.
   public int originalPosition;
   public int currentPosition;
   public String runnerLetter;
   public String name;
   public String moveDescription;
   public static List<Runner> allRunners = new ArrayList<Runner>(); //Static list because there should be one list for all objects
   
   public int getMovementType()
   {
      return random.nextInt(10) + 1; //Add 1 to include the last number "10"
   }
   
   //Makes the movements
   public void makeMovement(int spaces)
   {
      originalPosition = currentPosition;
      if (currentPosition + spaces < 0)
         currentPosition = 0;
      else if (currentPosition + spaces > RaceTrack.TRACK_LENGTH)
         currentPosition = RaceTrack.TRACK_LENGTH;
      else currentPosition += spaces;
   }
//Every runner will be of type Runner, one method for all classes
   public boolean isWinner(Runner runner)
   {
      if (runner.currentPosition == RaceTrack.TRACK_LENGTH)
         return true;
      return false;
   }
   public abstract void calculateMove();
}
