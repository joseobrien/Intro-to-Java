package tortoiseHareRace;

public class Tortoise extends Runner{ //Initializes variables that all runners have in common
   public Tortoise(int currentPosition, String name)
   {
      this.currentPosition = currentPosition;
      this.name = name;
      runnerLetter = "T";
      moveDescription = "The " + name + " is off!!";
      allRunners.add(this); //Adds the whole class to the list of runners
   }
   
   @Override
   public void calculateMove(){//For specific moves for the Tortoise
      System.out.println();
      int movement = getMovementType();
      
      if(movement >= 1 && movement <= 5){
         makeMovement(MovementType.FAST_PLOD);//Refers to the constant defined in the MovementType class
         moveDescription = name + "'s next move is a fast plod";
      }
      else if (movement >= 6 && movement <=8){
         makeMovement(MovementType.SLOW_PLOD);//Refers to the constant defined in the MovementType class
         moveDescription = name + "'s next move is a slow plod";
      }
      else {
         makeMovement(MovementType.SLIP);//Refers to the constant defined in the MovementType class
         moveDescription = name + " slips";
      }
   }
}
