/* The design and analysis can be found included the submitted zip file
 * The principal source used throughout the assignment can be found here: https://www.udemy.com/java-algorithms/
 * 
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Project 1
 */
package tortoiseHareRace;

public class TortoiseHareRace {
   public static void main (String[] args){
      Race race = new Race();
      race.racing();
   }
}
