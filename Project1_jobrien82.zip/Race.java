package tortoiseHareRace;

public class Race {
   private RaceTrack track; //Separate instance of the race track
   private boolean raceOver;
   
   public Race(){
      
      new Tortoise(0, "Tortoise");
      new Hare(0, "Hare");
      track = new RaceTrack();
      
      raceOver = false;
   }
   public void racing(){
      setUpRace();
      do{
         for(Runner runner : Runner.allRunners){
            runner.calculateMove();//Generates the runner movement
            track.runnerPosition(runner);//Places the runner in a new position
            System.out.println(runner.moveDescription); //Verifies visually what move the runner made
            
            if(runner.isWinner(runner)){
               raceOver = true;
            }
         }
         track.displayRaceTrack();
      }
      while(!raceOver); //The do while loop statement will execute until the race is over
      getResult();
   }
   public void getResult(){//Gets the result of the race
      for(Runner runner : Runner.allRunners){
         if(runner.currentPosition == RaceTrack.TRACK_LENGTH){
            System.out.println();
            System.out.println(runner.name + " wins!!");
         }
      }
   }
   private void setUpRace(){
      for(Runner runner : Runner.allRunners){
         track.runnerPosition(runner);
         System.out.println(runner.moveDescription);
      }
      track.displayRaceTrack();
   }
}
