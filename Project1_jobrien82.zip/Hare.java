package tortoiseHareRace;

public class Hare extends Runner {
   public Hare(int currentPosition, String name) {
      this.currentPosition = currentPosition;
      this.name = name;
      runnerLetter = "H";
      moveDescription = "The " + name + " is off!!";
      allRunners.add(this); //Adds the whole class to the list of runners
   }
   
   @Override
   public void calculateMove() {//For specific moves for the Hare
      
      int movement = getMovementType();
      
      if(movement == 1 || movement == 2 ){
         makeMovement(MovementType.BIG_HOP);//Refers to the constant defined in the MovementType class
         moveDescription = name + "'s next move is a big hop";
      }
      else if (movement >=3 && movement <= 5){
         makeMovement(MovementType.SMALL_HOP);//Refers to the constant defined in the MovementType class
         moveDescription = name + "'s next move is a small hop";
      }
      else if (movement == 6){
         makeMovement(MovementType.BIG_SLIP);//Refers to the constant defined in the MovementType class
         moveDescription = name + " has a big slip";
      }
      else if (movement == 7 || movement == 8){
         makeMovement(MovementType.SMALL_SLIP);//Refers to the constant defined in the MovementType class
         moveDescription = name + " has a small slip";
      }
      else {
         makeMovement(MovementType.FALL_ASLEEP);//Refers to the constant defined in the MovementType class
         moveDescription = name + " falls asleep";
      }
   }
}
