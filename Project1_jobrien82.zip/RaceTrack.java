package tortoiseHareRace;

public class RaceTrack {//Object oriented approach, which will allow to add multiple players without affecting the game's logic
   
   public static final int TRACK_LENGTH = 50;
   
   public String[] tracks;
   
   public RaceTrack() {
      tracks = new String[TRACK_LENGTH + 1]; //Add 1 given that the index starts at 0 to 49 for a total of 50 blocks, finishing at the 50th position
   }
   
   public void displayRaceTrack() {
      System.out.println("---------------------------------------------------");
      
      for (int trackSquare = 0; trackSquare <= TRACK_LENGTH; trackSquare++) //Less than or equal to in order to go to the finish line
      {
         if (tracks[trackSquare] == null)
            System.out.print(" ");
         else
            System.out.print(tracks[trackSquare]);
      }
      System.out.println();
      System.out.println("---------------------------------------------------");
   }
   
   public void runnerPosition(Runner runner) //Displays runner letter on the race track, polymorphic because it will work for different classes
   {
      tracks[runner.originalPosition] = null; //Erases the runner letter from the previous runner position
      
      tracks[runner.currentPosition] = runner.runnerLetter; //Current position is equals to column
   }
}
