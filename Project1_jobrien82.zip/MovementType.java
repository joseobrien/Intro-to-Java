package tortoiseHareRace;

public final class MovementType {//All the moves are placed in this class in order to change constant values here just once.
   public static final int FAST_PLOD = 3;
   public static final int SLOW_PLOD = 1;
   public static final int SLIP = -6;
   public static final int BIG_HOP = 9;
   public static final int SMALL_HOP = 1;
   public static final int BIG_SLIP = -12;
   public static final int SMALL_SLIP = -2;
   public static final int FALL_ASLEEP = 0;
   
}
