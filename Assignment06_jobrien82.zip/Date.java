package employeeDetails;

public class Date {
   private int month;
   private int day;
   private int year;
   public Date()
   {
      month = 0;
      year = 0;
      day = 0;
   }
   public void setDay( int dayOfMonth )
   {
      day = dayOfMonth;
   }
   public void setMonth( int monthOfYear )
   {
      month = monthOfYear;
   }
   public void setYear( int whichYear )
   {
      year = whichYear;
   }
   public int getDay()
   {
      return day;
   }
   public int getMonth()
   {
      return month;
   }
   public int getYear()
   {
      return year;
   }
   
   @Override
   public String toString (){//Used to override and assign the concatenated full hiring date 
      return String.format("%d-%d-%d", month, day, year);
   }
}
