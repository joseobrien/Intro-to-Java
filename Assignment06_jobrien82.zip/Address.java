package employeeDetails;

public class Address {
   private String Street;
   private String City;
   private String State;
   private String Zipcode; //Zipcode is established as a String given that it won't be used in a mathematical operation 
   
   public Address() {
      Street = "";
      City = "";
      State = "";
      Zipcode = "";
   }
   
   public void setStreet(String street) {
      Street = street;
   }
   
   public void setCity(String city) {
      City = city;
   }
   
   public void setState(String state) {
      State = state;
   }
   
   public void setZipcode(String zipcode) {
      Zipcode = zipcode;
   }
   
   public String getStreet() {
      return Street;
   }
   
   public String getCity() {
      return City;
   }
   
   public String getState() {
      return State;
   }
   
   public String getZipcode() {
      return Zipcode;
   }
   
   @Override
   public String toString() {//Used to override and assign the concatenated full address 
      return Street + ", " + City + ", " + State + " " + Zipcode;
   }
}