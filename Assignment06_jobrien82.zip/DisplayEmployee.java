/* According to the class assignment, the program has to model an employee, which has a set of attributes such name, address and hiring date.
 * These attributes themselves had further attributes, such as First and Last Name.
 * We need to create an Employee, a Name, an Address, and a Date classes in our solution, and we need to provide appropriate class constructors, getter methods, setter methods, toString() and any other methods. 
 * The classes should not do any direct user input/output. All user input/output will be done in the main method, which in my case is in this class "DisplayEmployee".
 * Finally, the program should prompt the user to enter data for several employees, store the data in an array of type Employee, and then display the data.
 * 
 * The principal source used throughout the assignment can be found here: https://stackoverflow.com/questions/29263154/
 * 
 * @author: Jose O'Brien
 * @course: EN.605.201.82.SU19 Intro to Programming Using Java
 * @module: Module 6
 */

package employeeDetails;

import java.util.Scanner;

public class DisplayEmployee {
   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      int numEmployees;
      System.out.println("How many employees do you wish to enter?"); //To establish the number of employees to be registered in the array
      
      numEmployees = Integer.parseInt(input.nextLine());
      Employee[] employeeArray = new Employee[numEmployees];
      for (int i = 0; i < numEmployees; i++) {
         Employee e1 = new Employee();
         Name name = new Name();
         Date dateHiring = new Date();
         Address address = new Address();
         
         System.out.println("Enter the first name of the employee:");
         name.setFirstName(input.nextLine());
         
         System.out.println("Enter the last name of the employee:");
         name.setLastName(input.nextLine());
         e1.setName(name); //First and last name are assigned to Name
         
         System.out.println("Enter the employee's current street address:");
         address.setStreet(input.nextLine());
         
         System.out.println("Enter the employee's current home city:");
         address.setCity(input.nextLine());
         
         System.out.println("Enter the employee's current home state:");
         address.setState(input.nextLine());
         
         System.out.println("Enter the employee's current zip code:");
         address.setZipcode(input.nextLine());
         e1.setAddress(address); //Street, city, state and zip code are assigned to Address 
         
         System.out.println("Enter the day of Hiring");
         dateHiring.setDay(Integer.parseInt(input.nextLine()));
         
         System.out.println("Enter the month of Hiring");
         dateHiring.setMonth(Integer.parseInt(input.nextLine()));
         
         System.out.println("Enter the year of Hiring");
         dateHiring.setYear(Integer.parseInt(input.nextLine()));
         e1.setHireDate(dateHiring); //Day, month and year are assigned to Date
         
         employeeArray[i] = e1;
      }
      for (Employee e : employeeArray) {//Displays the registered employees with their details, per the user input
         System.out.println();
         System.out.println(e.getName());
         System.out.println(e.getAddress());
         System.out.println(e.getHireDate());
      }
      input.close();
   }
}