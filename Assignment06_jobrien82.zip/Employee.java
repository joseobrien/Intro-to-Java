package employeeDetails;

public class Employee {
   private Name name;
   private Address address;
   private Date hireDate;
   
   public Name getName() {
      return name;
   }
   
   public void setName(Name name) {
      this.name = name;
   }
   
   public Address getAddress() {
      return address;
   }
   
   public void setAddress(Address address) {
      this.address = address;
   }
   
   public Date getHireDate() {
      return hireDate;
   }
   
   public void setHireDate(Date hireDate) {
      this.hireDate = hireDate;
   }
}