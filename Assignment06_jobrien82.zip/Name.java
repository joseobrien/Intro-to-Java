package employeeDetails;

public class Name {
   
   private String FirstName;
   private String LastName;
   public Name()
   {
      FirstName = "";
      LastName = "";
   }
   public void setFirstName(String firstName)
   {
      FirstName = firstName;
   }
   public void setLastName(String lastName)
   {
      LastName = lastName;
   }
   public String getFirstName()
   {
      return FirstName;
   }
   public String getLastName()
   {
      return LastName;
   }
   @Override
   public String toString() {
      return FirstName +" " + LastName;
   }
}
